/*
 * Author - Vikram Gopal
 * Title - Printing out to console.
 */
 
public class HelloWorld 
{
	public static void main (String [] args)
	{
		System.out.println("Hello GitHub!!");
	}

}
