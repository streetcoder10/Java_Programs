/*
 * Author - Vikram Gopal.
 * Title - Finding answer using declaring and variables.
 */

package Viky_Programs;

public class FindingAnswer 
{
	public static void main(String [] args)
	{
		int value1 = 10;		
		int value2 = value1+10;
		double value3 = value1+20-value2;
		double theAnswer = (value3*10)/10;
		
		System.out.println("The answer is: "+theAnswer);
	}
}
